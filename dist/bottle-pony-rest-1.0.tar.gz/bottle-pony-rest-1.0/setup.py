from distutils.core import setup

setup(
    name='bottle-pony-rest',
    version='1.0',
    packages=['bpr'],
    url='',
    license='MIT',
    author='hulygun',
    author_email='hulygun@gmail.com',
    description=''
)
